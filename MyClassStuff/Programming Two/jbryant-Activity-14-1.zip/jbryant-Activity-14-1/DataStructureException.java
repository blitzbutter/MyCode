/* The DataStructureException class
    Anderson, Franceschi
*/

public class DataStructureException extends Exception
{
 public DataStructureException( String s )
 {
  super( s );
 }
}
