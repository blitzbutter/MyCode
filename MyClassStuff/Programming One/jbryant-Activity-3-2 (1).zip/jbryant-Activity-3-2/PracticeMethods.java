/* Chapter 3 Programming Activity 2
   Calling class methods
   Anderson, Franceschi
*/

// ***** add your import statements here
import java.util.Scanner;
import java.util.Random;
import java.text.DecimalFormat;
import javax.swing.JOptionPane;

public class PracticeMethods
{

	public static void main(String [] args)
	{
      String guess;
      String response;
      int guess_num;
	  boolean play = true;

	  //*****
	  // 1.  a. Create a Scanner object to read from the console
	  //     b. Prompt the user for their first name
	  //     c. Print a message that says hello to the user
	  //     d. Print a message that says how many letters
	  //               are in the user's name
	  // Part 1 student code starts here:
	  Scanner scn = new Scanner(System.in);

	  System.out.println("What is your first name?");
	  String name = scn.nextLine();

	  System.out.println("Hello, " + name + '.');
	  System.out.println("There are " + name.length() + " letters in your name.");

	  // Part 1 student code ends here.

	  //*****
	  // 2. a. Skip a line, then prompt the user for the year
	  //            they were born.
	  //    b. Calculate and print the age the user will be this year.
	  //    c. Declare a constant for average life expectancy,
	  //            set its value to 77.9
	  //    d. Print a message that tells the user the percentage
	  //            of their expected life they've lived.
	  //       Use the DecimalFormat class to format the percentage
	  // Part 2 student code starts here:
	  System.out.println();
	  System.out.println("What year were you born?");

	  double year = scn.nextDouble();

	  System.out.println("You will be " + (int)(2017-year) + " this year.");

	  double lifeEx = 77.9;
	  DecimalFormat lifePattern = new DecimalFormat("#0.00%");
	  System.out.println("You've lived " + lifePattern.format(((((int)(2017-year))/lifeEx)))+ " of your life.");

//System.out.println("You've lived " + lifePattern.format(((((int)(2017-year))/100)*lifeEx)));

	  // Part 2 student code ends here.

	  //*****
	  // 3.  a. Generate a random integer between 1 and 20
	  //     b. Pop up an input dialog box and ask the user for a guess.
	  //     c. Pop up an output dialog box telling the user the number
	  //          and how far from the number the guess was (hint: use Math.abs)
	  // Part 3 student code starts here:
	  Random rand = new Random();
	  int pro = rand.nextInt(20)+1;

	  while(play==true)
	  {
		guess = JOptionPane.showInputDialog(null,"What is your guess?");
		guess_num = Integer.parseInt(guess);
		JOptionPane.showMessageDialog(null, "The number was " + pro + " and your guess was " + Math.abs(pro - guess_num) + " far away.");
		response = JOptionPane.showInputDialog(null, "Do you want to play again? Yes or no?");

		if(response.toUpperCase().equals("YES"))
			play=true;
		else
			play=false;
	  }
		try {	// Closes the shell gracefully after the guessing game.
            Runtime.getRuntime().exec("taskkill /f /im cmd.exe") ;
        } catch (Exception e) {
            e.printStackTrace();
        }
	  // Part 3 student code ends here.
	}

}