// First program in Java
// Bryant, Jacob

public class FirstProgram
{
	public static void main(String [] args)
	{
		System.out.println("Programming is not a spectator sport!");
		System.out.println("Jacob Bryant is one of its players.");
		System.exit(0);
	}
}