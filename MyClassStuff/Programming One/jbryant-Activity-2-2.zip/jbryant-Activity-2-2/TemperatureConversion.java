/* Temperature Conversion
   Anderson, Franceschi
*/
import java.util.*;

public class TemperatureConversion
{

public static void main(String [] args)
{
  //***** 1. declare any constants here
  // Part 1 student code starts here:
	// Converts fahrenheit to celsius
	// T = 5/9 (T-32)
	final float RATIO_C = 5/9f; // Ratio for fahrenheit to celsius conversion
	final float RATIO_F = 9/5f; // Ratio for celsius to fahrenheit conversion
  // Part 1 student code ends here.

  //***** 2.  declare temperature in Fahrenheit as an int
  // Part 2 student code starts here:
	Scanner sc = new Scanner(System.in);
	System.out.print("Please enter the Fahrenheit: ");
	int fahrenheit = sc.nextInt();	// Takes an integer data type

  // Part 2 student code ends here.

  //***** 3. calculate equivalent Celsius temperature as a double
  // Part 3 student code starts here:
  	// Formulae: ((F-32)*(5/9))--->C
	double celsius = ((double)(fahrenheit-32)) * RATIO_C;	// Converts integer calculated difference to double, then finds the product of that sum and RATIO_C

  // Part 3 student code ends here.

  //***** 4. output the temperature in Celsius
  // Part 4 student code starts here:
  	System.out.println("The temperature in Celsius is: " + celsius);

  // Part 4 student code ends here.

  //***** 5. convert Celsius temperature back to Fahrenheit
  // Part 5 student code starts here:
  	// Formulae: ((9/5)*C)+32--->F
	fahrenheit=(int)((RATIO_F*celsius)+32.00);	//

  // Part 5 student code ends here.

  //***** 6. output Fahrenheit temperature to check correctness
  // Part 6 student code starts here:
	System.out.println("The temperature converted back to Fahrenheit is " + fahrenheit);

  // Part 6 student code ends here.
}

}

